﻿namespace RSERP_APS21
{
    partial class frmColorPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cSilver = new System.Windows.Forms.PictureBox();
            this.cLightGray = new System.Windows.Forms.PictureBox();
            this.cRed = new System.Windows.Forms.PictureBox();
            this.cLightCoral = new System.Windows.Forms.PictureBox();
            this.cBurlyWood = new System.Windows.Forms.PictureBox();
            this.cDarkOrange = new System.Windows.Forms.PictureBox();
            this.cSandyBrown = new System.Windows.Forms.PictureBox();
            this.cLightSalmon = new System.Windows.Forms.PictureBox();
            this.cYellowGreen = new System.Windows.Forms.PictureBox();
            this.cDarkKhaki = new System.Windows.Forms.PictureBox();
            this.cPaleGoldenrod = new System.Windows.Forms.PictureBox();
            this.cWhite = new System.Windows.Forms.PictureBox();
            this.cMediumSpringGreen = new System.Windows.Forms.PictureBox();
            this.cMediumSeaGreen = new System.Windows.Forms.PictureBox();
            this.cLightGreen = new System.Windows.Forms.PictureBox();
            this.cDarkSeaGreen = new System.Windows.Forms.PictureBox();
            this.cPaleTurquoise = new System.Windows.Forms.PictureBox();
            this.cLightSeaGreen = new System.Windows.Forms.PictureBox();
            this.cAquamarine = new System.Windows.Forms.PictureBox();
            this.cMediumAquamarine = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.cSilver)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cLightGray)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cRed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cLightCoral)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cBurlyWood)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cDarkOrange)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cSandyBrown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cLightSalmon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cYellowGreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cDarkKhaki)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cPaleGoldenrod)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cWhite)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cMediumSpringGreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cMediumSeaGreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cLightGreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cDarkSeaGreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cPaleTurquoise)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cLightSeaGreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cAquamarine)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cMediumAquamarine)).BeginInit();
            this.SuspendLayout();
            // 
            // cSilver
            // 
            this.cSilver.BackColor = System.Drawing.Color.Silver;
            this.cSilver.Location = new System.Drawing.Point(4, 4);
            this.cSilver.Name = "cSilver";
            this.cSilver.Size = new System.Drawing.Size(26, 26);
            this.cSilver.TabIndex = 0;
            this.cSilver.TabStop = false;
            this.cSilver.Click += new System.EventHandler(this.cSilver_Click);
            // 
            // cLightGray
            // 
            this.cLightGray.BackColor = System.Drawing.Color.LightGray;
            this.cLightGray.Location = new System.Drawing.Point(35, 4);
            this.cLightGray.Name = "cLightGray";
            this.cLightGray.Size = new System.Drawing.Size(26, 26);
            this.cLightGray.TabIndex = 1;
            this.cLightGray.TabStop = false;
            this.cLightGray.Click += new System.EventHandler(this.cLightGray_Click);
            // 
            // cRed
            // 
            this.cRed.BackColor = System.Drawing.Color.Red;
            this.cRed.Location = new System.Drawing.Point(66, 4);
            this.cRed.Name = "cRed";
            this.cRed.Size = new System.Drawing.Size(26, 26);
            this.cRed.TabIndex = 2;
            this.cRed.TabStop = false;
            this.cRed.Click += new System.EventHandler(this.cRed_Click);
            // 
            // cLightCoral
            // 
            this.cLightCoral.BackColor = System.Drawing.Color.LightCoral;
            this.cLightCoral.Location = new System.Drawing.Point(98, 4);
            this.cLightCoral.Name = "cLightCoral";
            this.cLightCoral.Size = new System.Drawing.Size(26, 26);
            this.cLightCoral.TabIndex = 3;
            this.cLightCoral.TabStop = false;
            this.cLightCoral.Click += new System.EventHandler(this.cLightCoral_Click);
            // 
            // cBurlyWood
            // 
            this.cBurlyWood.BackColor = System.Drawing.Color.BurlyWood;
            this.cBurlyWood.Location = new System.Drawing.Point(98, 36);
            this.cBurlyWood.Name = "cBurlyWood";
            this.cBurlyWood.Size = new System.Drawing.Size(26, 26);
            this.cBurlyWood.TabIndex = 7;
            this.cBurlyWood.TabStop = false;
            this.cBurlyWood.Click += new System.EventHandler(this.cBurlyWood_Click);
            // 
            // cDarkOrange
            // 
            this.cDarkOrange.BackColor = System.Drawing.Color.DarkOrange;
            this.cDarkOrange.Location = new System.Drawing.Point(66, 36);
            this.cDarkOrange.Name = "cDarkOrange";
            this.cDarkOrange.Size = new System.Drawing.Size(26, 26);
            this.cDarkOrange.TabIndex = 6;
            this.cDarkOrange.TabStop = false;
            this.cDarkOrange.Click += new System.EventHandler(this.cDarkOrange_Click);
            // 
            // cSandyBrown
            // 
            this.cSandyBrown.BackColor = System.Drawing.Color.SandyBrown;
            this.cSandyBrown.Location = new System.Drawing.Point(35, 36);
            this.cSandyBrown.Name = "cSandyBrown";
            this.cSandyBrown.Size = new System.Drawing.Size(26, 26);
            this.cSandyBrown.TabIndex = 5;
            this.cSandyBrown.TabStop = false;
            this.cSandyBrown.Click += new System.EventHandler(this.cSandyBrown_Click);
            // 
            // cLightSalmon
            // 
            this.cLightSalmon.BackColor = System.Drawing.Color.LightSalmon;
            this.cLightSalmon.Location = new System.Drawing.Point(4, 36);
            this.cLightSalmon.Name = "cLightSalmon";
            this.cLightSalmon.Size = new System.Drawing.Size(26, 26);
            this.cLightSalmon.TabIndex = 4;
            this.cLightSalmon.TabStop = false;
            this.cLightSalmon.Click += new System.EventHandler(this.cLightSalmon_Click);
            // 
            // cYellowGreen
            // 
            this.cYellowGreen.BackColor = System.Drawing.Color.YellowGreen;
            this.cYellowGreen.Location = new System.Drawing.Point(98, 68);
            this.cYellowGreen.Name = "cYellowGreen";
            this.cYellowGreen.Size = new System.Drawing.Size(26, 26);
            this.cYellowGreen.TabIndex = 11;
            this.cYellowGreen.TabStop = false;
            this.cYellowGreen.Click += new System.EventHandler(this.cYellowGreen_Click);
            // 
            // cDarkKhaki
            // 
            this.cDarkKhaki.BackColor = System.Drawing.Color.DarkKhaki;
            this.cDarkKhaki.Location = new System.Drawing.Point(66, 68);
            this.cDarkKhaki.Name = "cDarkKhaki";
            this.cDarkKhaki.Size = new System.Drawing.Size(26, 26);
            this.cDarkKhaki.TabIndex = 10;
            this.cDarkKhaki.TabStop = false;
            this.cDarkKhaki.Click += new System.EventHandler(this.cDarkKhaki_Click);
            // 
            // cPaleGoldenrod
            // 
            this.cPaleGoldenrod.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.cPaleGoldenrod.Location = new System.Drawing.Point(35, 68);
            this.cPaleGoldenrod.Name = "cPaleGoldenrod";
            this.cPaleGoldenrod.Size = new System.Drawing.Size(26, 26);
            this.cPaleGoldenrod.TabIndex = 9;
            this.cPaleGoldenrod.TabStop = false;
            this.cPaleGoldenrod.Click += new System.EventHandler(this.cPaleGoldenrod_Click);
            // 
            // cWhite
            // 
            this.cWhite.BackColor = System.Drawing.Color.White;
            this.cWhite.Location = new System.Drawing.Point(4, 68);
            this.cWhite.Name = "cWhite";
            this.cWhite.Size = new System.Drawing.Size(26, 26);
            this.cWhite.TabIndex = 8;
            this.cWhite.TabStop = false;
            this.cWhite.Click += new System.EventHandler(this.cWhite_Click);
            // 
            // cMediumSpringGreen
            // 
            this.cMediumSpringGreen.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.cMediumSpringGreen.Location = new System.Drawing.Point(98, 100);
            this.cMediumSpringGreen.Name = "cMediumSpringGreen";
            this.cMediumSpringGreen.Size = new System.Drawing.Size(26, 26);
            this.cMediumSpringGreen.TabIndex = 15;
            this.cMediumSpringGreen.TabStop = false;
            this.cMediumSpringGreen.Click += new System.EventHandler(this.cMediumSpringGreen_Click);
            // 
            // cMediumSeaGreen
            // 
            this.cMediumSeaGreen.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.cMediumSeaGreen.Location = new System.Drawing.Point(66, 100);
            this.cMediumSeaGreen.Name = "cMediumSeaGreen";
            this.cMediumSeaGreen.Size = new System.Drawing.Size(26, 26);
            this.cMediumSeaGreen.TabIndex = 14;
            this.cMediumSeaGreen.TabStop = false;
            this.cMediumSeaGreen.Click += new System.EventHandler(this.cMediumSeaGreen_Click);
            // 
            // cLightGreen
            // 
            this.cLightGreen.BackColor = System.Drawing.Color.LightGreen;
            this.cLightGreen.Location = new System.Drawing.Point(35, 100);
            this.cLightGreen.Name = "cLightGreen";
            this.cLightGreen.Size = new System.Drawing.Size(26, 26);
            this.cLightGreen.TabIndex = 13;
            this.cLightGreen.TabStop = false;
            this.cLightGreen.Click += new System.EventHandler(this.cLightGreen_Click);
            // 
            // cDarkSeaGreen
            // 
            this.cDarkSeaGreen.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.cDarkSeaGreen.Location = new System.Drawing.Point(4, 100);
            this.cDarkSeaGreen.Name = "cDarkSeaGreen";
            this.cDarkSeaGreen.Size = new System.Drawing.Size(26, 26);
            this.cDarkSeaGreen.TabIndex = 12;
            this.cDarkSeaGreen.TabStop = false;
            this.cDarkSeaGreen.Click += new System.EventHandler(this.cDarkSeaGreen_Click);
            // 
            // cPaleTurquoise
            // 
            this.cPaleTurquoise.BackColor = System.Drawing.Color.PaleTurquoise;
            this.cPaleTurquoise.Location = new System.Drawing.Point(98, 132);
            this.cPaleTurquoise.Name = "cPaleTurquoise";
            this.cPaleTurquoise.Size = new System.Drawing.Size(26, 26);
            this.cPaleTurquoise.TabIndex = 19;
            this.cPaleTurquoise.TabStop = false;
            this.cPaleTurquoise.Click += new System.EventHandler(this.cPaleTurquoise_Click);
            // 
            // cLightSeaGreen
            // 
            this.cLightSeaGreen.BackColor = System.Drawing.Color.LightSeaGreen;
            this.cLightSeaGreen.Location = new System.Drawing.Point(66, 132);
            this.cLightSeaGreen.Name = "cLightSeaGreen";
            this.cLightSeaGreen.Size = new System.Drawing.Size(26, 26);
            this.cLightSeaGreen.TabIndex = 18;
            this.cLightSeaGreen.TabStop = false;
            this.cLightSeaGreen.Click += new System.EventHandler(this.cLightSeaGreen_Click);
            // 
            // cAquamarine
            // 
            this.cAquamarine.BackColor = System.Drawing.Color.Aquamarine;
            this.cAquamarine.Location = new System.Drawing.Point(35, 132);
            this.cAquamarine.Name = "cAquamarine";
            this.cAquamarine.Size = new System.Drawing.Size(26, 26);
            this.cAquamarine.TabIndex = 17;
            this.cAquamarine.TabStop = false;
            this.cAquamarine.Click += new System.EventHandler(this.cAquamarine_Click);
            // 
            // cMediumAquamarine
            // 
            this.cMediumAquamarine.BackColor = System.Drawing.Color.MediumAquamarine;
            this.cMediumAquamarine.Location = new System.Drawing.Point(4, 132);
            this.cMediumAquamarine.Name = "cMediumAquamarine";
            this.cMediumAquamarine.Size = new System.Drawing.Size(26, 26);
            this.cMediumAquamarine.TabIndex = 16;
            this.cMediumAquamarine.TabStop = false;
            this.cMediumAquamarine.Click += new System.EventHandler(this.cMediumAquamarine_Click);
            // 
            // frmColorPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(128, 164);
            this.Controls.Add(this.cPaleTurquoise);
            this.Controls.Add(this.cLightSeaGreen);
            this.Controls.Add(this.cAquamarine);
            this.Controls.Add(this.cMediumAquamarine);
            this.Controls.Add(this.cMediumSpringGreen);
            this.Controls.Add(this.cMediumSeaGreen);
            this.Controls.Add(this.cLightGreen);
            this.Controls.Add(this.cDarkSeaGreen);
            this.Controls.Add(this.cYellowGreen);
            this.Controls.Add(this.cDarkKhaki);
            this.Controls.Add(this.cPaleGoldenrod);
            this.Controls.Add(this.cWhite);
            this.Controls.Add(this.cBurlyWood);
            this.Controls.Add(this.cDarkOrange);
            this.Controls.Add(this.cSandyBrown);
            this.Controls.Add(this.cLightSalmon);
            this.Controls.Add(this.cLightCoral);
            this.Controls.Add(this.cRed);
            this.Controls.Add(this.cLightGray);
            this.Controls.Add(this.cSilver);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmColorPanel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "颜色面板";
            ((System.ComponentModel.ISupportInitialize)(this.cSilver)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cLightGray)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cRed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cLightCoral)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cBurlyWood)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cDarkOrange)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cSandyBrown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cLightSalmon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cYellowGreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cDarkKhaki)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cPaleGoldenrod)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cWhite)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cMediumSpringGreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cMediumSeaGreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cLightGreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cDarkSeaGreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cPaleTurquoise)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cLightSeaGreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cAquamarine)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cMediumAquamarine)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox cSilver;
        private System.Windows.Forms.PictureBox cLightGray;
        private System.Windows.Forms.PictureBox cRed;
        private System.Windows.Forms.PictureBox cLightCoral;
        private System.Windows.Forms.PictureBox cBurlyWood;
        private System.Windows.Forms.PictureBox cDarkOrange;
        private System.Windows.Forms.PictureBox cSandyBrown;
        private System.Windows.Forms.PictureBox cLightSalmon;
        private System.Windows.Forms.PictureBox cYellowGreen;
        private System.Windows.Forms.PictureBox cDarkKhaki;
        private System.Windows.Forms.PictureBox cPaleGoldenrod;
        private System.Windows.Forms.PictureBox cWhite;
        private System.Windows.Forms.PictureBox cMediumSpringGreen;
        private System.Windows.Forms.PictureBox cMediumSeaGreen;
        private System.Windows.Forms.PictureBox cLightGreen;
        private System.Windows.Forms.PictureBox cDarkSeaGreen;
        private System.Windows.Forms.PictureBox cPaleTurquoise;
        private System.Windows.Forms.PictureBox cLightSeaGreen;
        private System.Windows.Forms.PictureBox cAquamarine;
        private System.Windows.Forms.PictureBox cMediumAquamarine;
    }
}