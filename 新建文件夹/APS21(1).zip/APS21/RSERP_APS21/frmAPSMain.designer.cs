﻿namespace RSERP_APS21
{
    partial class frmRSERP_APS21Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRSERP_APS21Main));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tab5OrderTotal = new System.Windows.Forms.TabPage();
            this.tab7DeliverySchedule = new System.Windows.Forms.TabPage();
            this.tab6APS = new System.Windows.Forms.TabPage();
            this.tab6_dataGridView1 = new System.Windows.Forms.DataGridView();
            this.contextMenu_Tab6 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cmtab6FindSimilarity = new System.Windows.Forms.ToolStripMenuItem();
            this.cmtab6Findword = new System.Windows.Forms.ToolStripMenuItem();
            this.cmtab6Moallocate = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripSeparator();
            this.cmtab6Copy = new System.Windows.Forms.ToolStripMenuItem();
            this.cmtab6Paste = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.cmtab6RowCut = new System.Windows.Forms.ToolStripMenuItem();
            this.cmtab6RowPaste = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.cmtab6Plan = new System.Windows.Forms.ToolStripMenuItem();
            this.cmtab6Priority = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripSeparator();
            this.cmtab6Sure2 = new System.Windows.Forms.ToolStripMenuItem();
            this.cmtab6NotSure = new System.Windows.Forms.ToolStripMenuItem();
            this.cmtab6ChangeDate = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.cmtab6Close = new System.Windows.Forms.ToolStripMenuItem();
            this.cmtab6NotColse = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.cmtab6OrderSplit = new System.Windows.Forms.ToolStripMenuItem();
            this.cmtab6OrderMerge = new System.Windows.Forms.ToolStripMenuItem();
            this.cmtab6ReLoadBOM = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripSeparator();
            this.cmtab6SelectAll = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.cmtab6Colors = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.cmtab6MissingMaterials = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.cmtab6_other = new System.Windows.Forms.ToolStripMenuItem();
            this.cmtab6_oth_ResetColumnsWidth = new System.Windows.Forms.ToolStripMenuItem();
            this.字体大小ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cmtab6_Font8 = new System.Windows.Forms.ToolStripMenuItem();
            this.cmtab6_Font9 = new System.Windows.Forms.ToolStripMenuItem();
            this.cmtab6_Font10 = new System.Windows.Forms.ToolStripMenuItem();
            this.cmtab6_Font11 = new System.Windows.Forms.ToolStripMenuItem();
            this.cmtab6_Font12 = new System.Windows.Forms.ToolStripMenuItem();
            this.cmtab6_Font13 = new System.Windows.Forms.ToolStripMenuItem();
            this.cmtab6_Font14 = new System.Windows.Forms.ToolStripMenuItem();
            this.cmtab6_Font15 = new System.Windows.Forms.ToolStripMenuItem();
            this.cmtab6_Font16 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripSeparator();
            this.cmtab6ColumnFrozen = new System.Windows.Forms.ToolStripMenuItem();
            this.cmtab6ColumnNotFrozen = new System.Windows.Forms.ToolStripMenuItem();
            this.tab8MOMSupply = new System.Windows.Forms.TabPage();
            this.tab8_dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tab1AllStock = new System.Windows.Forms.TabPage();
            this.tab2_DateHCHK = new System.Windows.Forms.CheckBox();
            this.tab2_DateLCHK = new System.Windows.Forms.CheckBox();
            this.tab2_cinvCodeAny = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tab2_chkMissingOnly = new System.Windows.Forms.CheckBox();
            this.tab2_dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tab2_cinvcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tab2_cInvName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tab2_cInvStd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tab2_cInvDefine7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tab2_moQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tab2_Now_PurQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tab2_toArrQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tab2_Now_PurArrQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tab2_CurSotckQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tab2_AltmQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tab2_allSotckQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tab2_useQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tab2_AvailableQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tab1_chkPurQtyState = new System.Windows.Forms.CheckBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tab2_DateH = new System.Windows.Forms.DateTimePicker();
            this.tab2_DateL = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.tab2_cInvCodeL = new System.Windows.Forms.TextBox();
            this.tab2_cInvCodeH = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tab2AllStockDetail = new System.Windows.Forms.TabPage();
            this.tab1_chkShow67 = new System.Windows.Forms.CheckBox();
            this.tab1_chkShow5 = new System.Windows.Forms.CheckBox();
            this.tab1_chkShow4 = new System.Windows.Forms.CheckBox();
            this.tab1_chkShow3 = new System.Windows.Forms.CheckBox();
            this.tab1_chkShow12 = new System.Windows.Forms.CheckBox();
            this.chkShowAll = new System.Windows.Forms.CheckBox();
            this.chkShowProd = new System.Windows.Forms.CheckBox();
            this.tab1_cinvCodeAny = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tab1_cInvCodeL = new System.Windows.Forms.TextBox();
            this.tab1_cInvCodeH = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tab1_dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tab3PurSource = new System.Windows.Forms.TabPage();
            this.tab3_dDateHCHK = new System.Windows.Forms.CheckBox();
            this.tab3_dDateLCHK = new System.Windows.Forms.CheckBox();
            this.tab3_cMaker = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.tab3_dDateH = new System.Windows.Forms.DateTimePicker();
            this.tab3_dDateL = new System.Windows.Forms.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.tab3_cCode = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tab3_cInvCode = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tab3_dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tab4MoSource = new System.Windows.Forms.TabPage();
            this.tab4_CreateUser = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.tab4_MoCode = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.tab4_cInvCode = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.tab4_dataGridView1 = new System.Windows.Forms.DataGridView();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolQuery = new System.Windows.Forms.ToolStripButton();
            this.toolRefresh = new System.Windows.Forms.ToolStripButton();
            this.toolEdit = new System.Windows.Forms.ToolStripButton();
            this.toolSave = new System.Windows.Forms.ToolStripButton();
            this.toolToExcel = new System.Windows.Forms.ToolStripButton();
            this.toolClose = new System.Windows.Forms.ToolStripButton();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.SLbServer = new System.Windows.Forms.ToolStripStatusLabel();
            this.SLbAccID = new System.Windows.Forms.ToolStripStatusLabel();
            this.SLbAccName = new System.Windows.Forms.ToolStripStatusLabel();
            this.SLbYear = new System.Windows.Forms.ToolStripStatusLabel();
            this.SLbUser = new System.Windows.Forms.ToolStripStatusLabel();
            this.SLBLoginDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.SLBTotal = new System.Windows.Forms.ToolStripStatusLabel();
            this.SLbState = new System.Windows.Forms.ToolStripStatusLabel();
            this.tab6_StandardCut = new System.Windows.Forms.ToolStripMenuItem();
            this.tab6_toStandard = new System.Windows.Forms.ToolStripMenuItem();
            this.tab6_toNotStandard = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl1.SuspendLayout();
            this.tab6APS.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tab6_dataGridView1)).BeginInit();
            this.contextMenu_Tab6.SuspendLayout();
            this.tab8MOMSupply.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tab8_dataGridView1)).BeginInit();
            this.tab1AllStock.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tab2_dataGridView1)).BeginInit();
            this.tab2AllStockDetail.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tab1_dataGridView1)).BeginInit();
            this.tab3PurSource.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tab3_dataGridView1)).BeginInit();
            this.tab4MoSource.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tab4_dataGridView1)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.tabControl1.Controls.Add(this.tab5OrderTotal);
            this.tabControl1.Controls.Add(this.tab7DeliverySchedule);
            this.tabControl1.Controls.Add(this.tab6APS);
            this.tabControl1.Controls.Add(this.tab8MOMSupply);
            this.tabControl1.Controls.Add(this.tab1AllStock);
            this.tabControl1.Controls.Add(this.tab2AllStockDetail);
            this.tabControl1.Controls.Add(this.tab3PurSource);
            this.tabControl1.Controls.Add(this.tab4MoSource);
            this.tabControl1.Location = new System.Drawing.Point(4, 43);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1276, 699);
            this.tabControl1.TabIndex = 56;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tab5OrderTotal
            // 
            this.tab5OrderTotal.Location = new System.Drawing.Point(4, 4);
            this.tab5OrderTotal.Name = "tab5OrderTotal";
            this.tab5OrderTotal.Size = new System.Drawing.Size(1268, 673);
            this.tab5OrderTotal.TabIndex = 4;
            this.tab5OrderTotal.Text = "综合统计";
            this.tab5OrderTotal.UseVisualStyleBackColor = true;
            // 
            // tab7DeliverySchedule
            // 
            this.tab7DeliverySchedule.Location = new System.Drawing.Point(4, 4);
            this.tab7DeliverySchedule.Name = "tab7DeliverySchedule";
            this.tab7DeliverySchedule.Size = new System.Drawing.Size(1268, 673);
            this.tab7DeliverySchedule.TabIndex = 6;
            this.tab7DeliverySchedule.Text = "交货计划";
            this.tab7DeliverySchedule.UseVisualStyleBackColor = true;
            // 
            // tab6APS
            // 
            this.tab6APS.Controls.Add(this.tab6_dataGridView1);
            this.tab6APS.Location = new System.Drawing.Point(4, 4);
            this.tab6APS.Name = "tab6APS";
            this.tab6APS.Size = new System.Drawing.Size(1268, 673);
            this.tab6APS.TabIndex = 5;
            this.tab6APS.Text = "排产管理";
            this.tab6APS.UseVisualStyleBackColor = true;
            // 
            // tab6_dataGridView1
            // 
            this.tab6_dataGridView1.AllowUserToAddRows = false;
            this.tab6_dataGridView1.AllowUserToDeleteRows = false;
            this.tab6_dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tab6_dataGridView1.ContextMenuStrip = this.contextMenu_Tab6;
            this.tab6_dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.tab6_dataGridView1.Location = new System.Drawing.Point(3, 3);
            this.tab6_dataGridView1.Name = "tab6_dataGridView1";
            this.tab6_dataGridView1.RowTemplate.Height = 23;
            this.tab6_dataGridView1.Size = new System.Drawing.Size(1264, 670);
            this.tab6_dataGridView1.TabIndex = 80;
            this.tab6_dataGridView1.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.tab6_dataGridView1_CellMouseUp);
            this.tab6_dataGridView1.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.tab6_dataGridView1_CellMouseDown);
            this.tab6_dataGridView1.CellMouseMove += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.tab6_dataGridView1_CellMouseMove);
            this.tab6_dataGridView1.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.tab6_dataGridView1_CellMouseDoubleClick);
            this.tab6_dataGridView1.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.tab6_dataGridView1_EditingControlShowing);
            this.tab6_dataGridView1.ColumnWidthChanged += new System.Windows.Forms.DataGridViewColumnEventHandler(this.tab6_dataGridView1_ColumnWidthChanged);
            this.tab6_dataGridView1.Click += new System.EventHandler(this.tab6_dataGridView1_Click);
            // 
            // contextMenu_Tab6
            // 
            this.contextMenu_Tab6.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmtab6FindSimilarity,
            this.cmtab6Findword,
            this.cmtab6Moallocate,
            this.toolStripMenuItem8,
            this.cmtab6Copy,
            this.cmtab6Paste,
            this.toolStripMenuItem5,
            this.cmtab6RowCut,
            this.cmtab6RowPaste,
            this.toolStripMenuItem1,
            this.cmtab6Plan,
            this.toolStripMenuItem6,
            this.cmtab6SelectAll,
            this.toolStripMenuItem4,
            this.cmtab6Colors,
            this.toolStripMenuItem2,
            this.cmtab6MissingMaterials,
            this.toolStripMenuItem3,
            this.cmtab6_other});
            this.contextMenu_Tab6.Name = "contextMenu_Tab6";
            this.contextMenu_Tab6.Size = new System.Drawing.Size(154, 332);
            // 
            // cmtab6FindSimilarity
            // 
            this.cmtab6FindSimilarity.Name = "cmtab6FindSimilarity";
            this.cmtab6FindSimilarity.Size = new System.Drawing.Size(153, 22);
            this.cmtab6FindSimilarity.Text = "搜相似...";
            this.cmtab6FindSimilarity.Click += new System.EventHandler(this.cmtab6FindSimilarity_Click);
            // 
            // cmtab6Findword
            // 
            this.cmtab6Findword.Name = "cmtab6Findword";
            this.cmtab6Findword.Size = new System.Drawing.Size(153, 22);
            this.cmtab6Findword.Text = "查找...";
            this.cmtab6Findword.Click += new System.EventHandler(this.cmtab6Findword_Click);
            // 
            // cmtab6Moallocate
            // 
            this.cmtab6Moallocate.Name = "cmtab6Moallocate";
            this.cmtab6Moallocate.Size = new System.Drawing.Size(153, 22);
            this.cmtab6Moallocate.Text = "查看子件";
            this.cmtab6Moallocate.Click += new System.EventHandler(this.cmtab6Moallocate_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(150, 6);
            // 
            // cmtab6Copy
            // 
            this.cmtab6Copy.Name = "cmtab6Copy";
            this.cmtab6Copy.Size = new System.Drawing.Size(153, 22);
            this.cmtab6Copy.Text = "复制";
            this.cmtab6Copy.Click += new System.EventHandler(this.cmtab6Copy_Click);
            // 
            // cmtab6Paste
            // 
            this.cmtab6Paste.Name = "cmtab6Paste";
            this.cmtab6Paste.Size = new System.Drawing.Size(153, 22);
            this.cmtab6Paste.Text = "粘贴";
            this.cmtab6Paste.Click += new System.EventHandler(this.cmtab6Paste_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(150, 6);
            // 
            // cmtab6RowCut
            // 
            this.cmtab6RowCut.Name = "cmtab6RowCut";
            this.cmtab6RowCut.Size = new System.Drawing.Size(153, 22);
            this.cmtab6RowCut.Text = "行剪切";
            this.cmtab6RowCut.Click += new System.EventHandler(this.cmtab6RowCut_Click);
            // 
            // cmtab6RowPaste
            // 
            this.cmtab6RowPaste.Name = "cmtab6RowPaste";
            this.cmtab6RowPaste.Size = new System.Drawing.Size(153, 22);
            this.cmtab6RowPaste.Text = "行粘贴";
            this.cmtab6RowPaste.Click += new System.EventHandler(this.cmtab6RowPaste_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(150, 6);
            // 
            // cmtab6Plan
            // 
            this.cmtab6Plan.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmtab6Priority,
            this.toolStripMenuItem9,
            this.cmtab6Sure2,
            this.cmtab6NotSure,
            this.cmtab6ChangeDate,
            this.toolStripSeparator1,
            this.cmtab6Close,
            this.cmtab6NotColse,
            this.toolStripSeparator2,
            this.cmtab6OrderSplit,
            this.cmtab6OrderMerge,
            this.cmtab6ReLoadBOM,
            this.tab6_StandardCut});
            this.cmtab6Plan.Name = "cmtab6Plan";
            this.cmtab6Plan.Size = new System.Drawing.Size(153, 22);
            this.cmtab6Plan.Text = "排产";
            // 
            // cmtab6Priority
            // 
            this.cmtab6Priority.Name = "cmtab6Priority";
            this.cmtab6Priority.Size = new System.Drawing.Size(177, 22);
            this.cmtab6Priority.Text = "优先级";
            this.cmtab6Priority.Click += new System.EventHandler(this.cmtab6Priority_Click);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(174, 6);
            // 
            // cmtab6Sure2
            // 
            this.cmtab6Sure2.Name = "cmtab6Sure2";
            this.cmtab6Sure2.Size = new System.Drawing.Size(177, 22);
            this.cmtab6Sure2.Text = "投产";
            this.cmtab6Sure2.Click += new System.EventHandler(this.cmtab6Sure2_Click);
            // 
            // cmtab6NotSure
            // 
            this.cmtab6NotSure.Name = "cmtab6NotSure";
            this.cmtab6NotSure.Size = new System.Drawing.Size(177, 22);
            this.cmtab6NotSure.Text = "取消投产";
            this.cmtab6NotSure.Click += new System.EventHandler(this.cmtab6NotSure_Click);
            // 
            // cmtab6ChangeDate
            // 
            this.cmtab6ChangeDate.Name = "cmtab6ChangeDate";
            this.cmtab6ChangeDate.Size = new System.Drawing.Size(177, 22);
            this.cmtab6ChangeDate.Text = "批改生产日期";
            this.cmtab6ChangeDate.Click += new System.EventHandler(this.cmtab6ChangeDate_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(174, 6);
            // 
            // cmtab6Close
            // 
            this.cmtab6Close.Name = "cmtab6Close";
            this.cmtab6Close.Size = new System.Drawing.Size(177, 22);
            this.cmtab6Close.Text = "结案";
            this.cmtab6Close.Click += new System.EventHandler(this.cmtab6Close_Click);
            // 
            // cmtab6NotColse
            // 
            this.cmtab6NotColse.Name = "cmtab6NotColse";
            this.cmtab6NotColse.Size = new System.Drawing.Size(177, 22);
            this.cmtab6NotColse.Text = "取消结案";
            this.cmtab6NotColse.Click += new System.EventHandler(this.cmtab6NotColse_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(174, 6);
            // 
            // cmtab6OrderSplit
            // 
            this.cmtab6OrderSplit.Name = "cmtab6OrderSplit";
            this.cmtab6OrderSplit.Size = new System.Drawing.Size(177, 22);
            this.cmtab6OrderSplit.Text = "分批生产";
            this.cmtab6OrderSplit.Click += new System.EventHandler(this.cmtab6OrderSplit_Click);
            // 
            // cmtab6OrderMerge
            // 
            this.cmtab6OrderMerge.Name = "cmtab6OrderMerge";
            this.cmtab6OrderMerge.Size = new System.Drawing.Size(177, 22);
            this.cmtab6OrderMerge.Text = "合并生产";
            this.cmtab6OrderMerge.Visible = false;
            this.cmtab6OrderMerge.Click += new System.EventHandler(this.cmtab6OrderMerge_Click);
            // 
            // cmtab6ReLoadBOM
            // 
            this.cmtab6ReLoadBOM.Name = "cmtab6ReLoadBOM";
            this.cmtab6ReLoadBOM.Size = new System.Drawing.Size(177, 22);
            this.cmtab6ReLoadBOM.Text = "重载BOM";
            this.cmtab6ReLoadBOM.Click += new System.EventHandler(this.cmtab6ReLoadBOM_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(150, 6);
            // 
            // cmtab6SelectAll
            // 
            this.cmtab6SelectAll.Name = "cmtab6SelectAll";
            this.cmtab6SelectAll.Size = new System.Drawing.Size(153, 22);
            this.cmtab6SelectAll.Text = "全选";
            this.cmtab6SelectAll.Click += new System.EventHandler(this.cmtab6SelectAll_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(150, 6);
            // 
            // cmtab6Colors
            // 
            this.cmtab6Colors.Name = "cmtab6Colors";
            this.cmtab6Colors.Size = new System.Drawing.Size(153, 22);
            this.cmtab6Colors.Text = "颜色标记";
            this.cmtab6Colors.Click += new System.EventHandler(this.cmtab6Colors_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(150, 6);
            // 
            // cmtab6MissingMaterials
            // 
            this.cmtab6MissingMaterials.Name = "cmtab6MissingMaterials";
            this.cmtab6MissingMaterials.Size = new System.Drawing.Size(153, 22);
            this.cmtab6MissingMaterials.Text = "进度/欠料分析";
            this.cmtab6MissingMaterials.Click += new System.EventHandler(this.cmtab6MissingMaterials_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(150, 6);
            // 
            // cmtab6_other
            // 
            this.cmtab6_other.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmtab6_oth_ResetColumnsWidth,
            this.字体大小ToolStripMenuItem,
            this.toolStripMenuItem7,
            this.cmtab6ColumnFrozen,
            this.cmtab6ColumnNotFrozen});
            this.cmtab6_other.Name = "cmtab6_other";
            this.cmtab6_other.Size = new System.Drawing.Size(153, 22);
            this.cmtab6_other.Text = "其他";
            // 
            // cmtab6_oth_ResetColumnsWidth
            // 
            this.cmtab6_oth_ResetColumnsWidth.Name = "cmtab6_oth_ResetColumnsWidth";
            this.cmtab6_oth_ResetColumnsWidth.Size = new System.Drawing.Size(124, 22);
            this.cmtab6_oth_ResetColumnsWidth.Text = "恢复列宽";
            this.cmtab6_oth_ResetColumnsWidth.Click += new System.EventHandler(this.cmtab6_oth_ResetColumnsWidth_Click);
            // 
            // 字体大小ToolStripMenuItem
            // 
            this.字体大小ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmtab6_Font8,
            this.cmtab6_Font9,
            this.cmtab6_Font10,
            this.cmtab6_Font11,
            this.cmtab6_Font12,
            this.cmtab6_Font13,
            this.cmtab6_Font14,
            this.cmtab6_Font15,
            this.cmtab6_Font16});
            this.字体大小ToolStripMenuItem.Name = "字体大小ToolStripMenuItem";
            this.字体大小ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.字体大小ToolStripMenuItem.Text = "字体大小";
            // 
            // cmtab6_Font8
            // 
            this.cmtab6_Font8.Name = "cmtab6_Font8";
            this.cmtab6_Font8.Size = new System.Drawing.Size(90, 22);
            this.cmtab6_Font8.Text = "8";
            this.cmtab6_Font8.Click += new System.EventHandler(this.cmtab6_Font8_Click);
            // 
            // cmtab6_Font9
            // 
            this.cmtab6_Font9.Name = "cmtab6_Font9";
            this.cmtab6_Font9.Size = new System.Drawing.Size(90, 22);
            this.cmtab6_Font9.Text = "9";
            this.cmtab6_Font9.Click += new System.EventHandler(this.cmtab6_Font9_Click);
            // 
            // cmtab6_Font10
            // 
            this.cmtab6_Font10.Name = "cmtab6_Font10";
            this.cmtab6_Font10.Size = new System.Drawing.Size(90, 22);
            this.cmtab6_Font10.Text = "10";
            this.cmtab6_Font10.Click += new System.EventHandler(this.cmtab6_Font10_Click);
            // 
            // cmtab6_Font11
            // 
            this.cmtab6_Font11.Name = "cmtab6_Font11";
            this.cmtab6_Font11.Size = new System.Drawing.Size(90, 22);
            this.cmtab6_Font11.Text = "11";
            this.cmtab6_Font11.Click += new System.EventHandler(this.cmtab6_Font11_Click);
            // 
            // cmtab6_Font12
            // 
            this.cmtab6_Font12.Name = "cmtab6_Font12";
            this.cmtab6_Font12.Size = new System.Drawing.Size(90, 22);
            this.cmtab6_Font12.Text = "12";
            this.cmtab6_Font12.Click += new System.EventHandler(this.cmtab6_Font12_Click);
            // 
            // cmtab6_Font13
            // 
            this.cmtab6_Font13.Name = "cmtab6_Font13";
            this.cmtab6_Font13.Size = new System.Drawing.Size(90, 22);
            this.cmtab6_Font13.Text = "13";
            this.cmtab6_Font13.Click += new System.EventHandler(this.cmtab6_Font13_Click);
            // 
            // cmtab6_Font14
            // 
            this.cmtab6_Font14.Name = "cmtab6_Font14";
            this.cmtab6_Font14.Size = new System.Drawing.Size(90, 22);
            this.cmtab6_Font14.Text = "14";
            this.cmtab6_Font14.Click += new System.EventHandler(this.cmtab6_Font14_Click);
            // 
            // cmtab6_Font15
            // 
            this.cmtab6_Font15.Name = "cmtab6_Font15";
            this.cmtab6_Font15.Size = new System.Drawing.Size(90, 22);
            this.cmtab6_Font15.Text = "15";
            this.cmtab6_Font15.Click += new System.EventHandler(this.cmtab6_Font15_Click);
            // 
            // cmtab6_Font16
            // 
            this.cmtab6_Font16.Name = "cmtab6_Font16";
            this.cmtab6_Font16.Size = new System.Drawing.Size(90, 22);
            this.cmtab6_Font16.Text = "16";
            this.cmtab6_Font16.Click += new System.EventHandler(this.cmtab6_Font16_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(121, 6);
            // 
            // cmtab6ColumnFrozen
            // 
            this.cmtab6ColumnFrozen.Name = "cmtab6ColumnFrozen";
            this.cmtab6ColumnFrozen.Size = new System.Drawing.Size(124, 22);
            this.cmtab6ColumnFrozen.Text = "列冻结";
            this.cmtab6ColumnFrozen.Click += new System.EventHandler(this.cmtab6ColumnFrozen_Click);
            // 
            // cmtab6ColumnNotFrozen
            // 
            this.cmtab6ColumnNotFrozen.Name = "cmtab6ColumnNotFrozen";
            this.cmtab6ColumnNotFrozen.Size = new System.Drawing.Size(124, 22);
            this.cmtab6ColumnNotFrozen.Text = "列解冻";
            this.cmtab6ColumnNotFrozen.Click += new System.EventHandler(this.cmtab6ColumnNotFrozen_Click);
            // 
            // tab8MOMSupply
            // 
            this.tab8MOMSupply.Controls.Add(this.tab8_dataGridView1);
            this.tab8MOMSupply.Location = new System.Drawing.Point(4, 4);
            this.tab8MOMSupply.Name = "tab8MOMSupply";
            this.tab8MOMSupply.Size = new System.Drawing.Size(1268, 673);
            this.tab8MOMSupply.TabIndex = 7;
            this.tab8MOMSupply.Text = "供应与进度";
            this.tab8MOMSupply.UseVisualStyleBackColor = true;
            // 
            // tab8_dataGridView1
            // 
            this.tab8_dataGridView1.AllowUserToAddRows = false;
            this.tab8_dataGridView1.AllowUserToDeleteRows = false;
            this.tab8_dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tab8_dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.tab8_dataGridView1.Location = new System.Drawing.Point(4, 3);
            this.tab8_dataGridView1.Name = "tab8_dataGridView1";
            this.tab8_dataGridView1.RowTemplate.Height = 23;
            this.tab8_dataGridView1.Size = new System.Drawing.Size(1260, 667);
            this.tab8_dataGridView1.TabIndex = 96;
            // 
            // tab1AllStock
            // 
            this.tab1AllStock.Controls.Add(this.tab2_DateHCHK);
            this.tab1AllStock.Controls.Add(this.tab2_DateLCHK);
            this.tab1AllStock.Controls.Add(this.tab2_cinvCodeAny);
            this.tab1AllStock.Controls.Add(this.label6);
            this.tab1AllStock.Controls.Add(this.tab2_chkMissingOnly);
            this.tab1AllStock.Controls.Add(this.tab2_dataGridView1);
            this.tab1AllStock.Controls.Add(this.tab1_chkPurQtyState);
            this.tab1AllStock.Controls.Add(this.label10);
            this.tab1AllStock.Controls.Add(this.tab2_DateH);
            this.tab1AllStock.Controls.Add(this.tab2_DateL);
            this.tab1AllStock.Controls.Add(this.label3);
            this.tab1AllStock.Controls.Add(this.tab2_cInvCodeL);
            this.tab1AllStock.Controls.Add(this.tab2_cInvCodeH);
            this.tab1AllStock.Controls.Add(this.label1);
            this.tab1AllStock.Controls.Add(this.label2);
            this.tab1AllStock.Location = new System.Drawing.Point(4, 4);
            this.tab1AllStock.Name = "tab1AllStock";
            this.tab1AllStock.Padding = new System.Windows.Forms.Padding(3);
            this.tab1AllStock.Size = new System.Drawing.Size(1268, 673);
            this.tab1AllStock.TabIndex = 0;
            this.tab1AllStock.Text = "库存";
            this.tab1AllStock.UseVisualStyleBackColor = true;
            // 
            // tab2_DateHCHK
            // 
            this.tab2_DateHCHK.AutoSize = true;
            this.tab2_DateHCHK.Location = new System.Drawing.Point(276, 47);
            this.tab2_DateHCHK.Name = "tab2_DateHCHK";
            this.tab2_DateHCHK.Size = new System.Drawing.Size(15, 14);
            this.tab2_DateHCHK.TabIndex = 77;
            this.tab2_DateHCHK.UseVisualStyleBackColor = true;
            this.tab2_DateHCHK.CheckedChanged += new System.EventHandler(this.tab2_DateHCHK_CheckedChanged);
            // 
            // tab2_DateLCHK
            // 
            this.tab2_DateLCHK.AutoSize = true;
            this.tab2_DateLCHK.Location = new System.Drawing.Point(94, 47);
            this.tab2_DateLCHK.Name = "tab2_DateLCHK";
            this.tab2_DateLCHK.Size = new System.Drawing.Size(15, 14);
            this.tab2_DateLCHK.TabIndex = 76;
            this.tab2_DateLCHK.UseVisualStyleBackColor = true;
            this.tab2_DateLCHK.CheckedChanged += new System.EventHandler(this.tab2_DateLCHK_CheckedChanged);
            // 
            // tab2_cinvCodeAny
            // 
            this.tab2_cinvCodeAny.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tab2_cinvCodeAny.Location = new System.Drawing.Point(733, 10);
            this.tab2_cinvCodeAny.Name = "tab2_cinvCodeAny";
            this.tab2_cinvCodeAny.Size = new System.Drawing.Size(519, 25);
            this.tab2_cinvCodeAny.TabIndex = 75;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(564, 14);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(158, 15);
            this.label6.TabIndex = 74;
            this.label6.Text = "多个物料(以分号隔开)";
            // 
            // tab2_chkMissingOnly
            // 
            this.tab2_chkMissingOnly.AutoSize = true;
            this.tab2_chkMissingOnly.Location = new System.Drawing.Point(566, 47);
            this.tab2_chkMissingOnly.Name = "tab2_chkMissingOnly";
            this.tab2_chkMissingOnly.Size = new System.Drawing.Size(132, 16);
            this.tab2_chkMissingOnly.TabIndex = 73;
            this.tab2_chkMissingOnly.Text = "仅显示已排产且欠料";
            this.tab2_chkMissingOnly.UseVisualStyleBackColor = true;
            // 
            // tab2_dataGridView1
            // 
            this.tab2_dataGridView1.AllowUserToAddRows = false;
            this.tab2_dataGridView1.AllowUserToDeleteRows = false;
            this.tab2_dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tab2_dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.tab2_cinvcode,
            this.tab2_cInvName,
            this.tab2_cInvStd,
            this.tab2_cInvDefine7,
            this.tab2_moQty,
            this.tab2_Now_PurQty,
            this.tab2_toArrQty,
            this.tab2_Now_PurArrQty,
            this.tab2_CurSotckQty,
            this.tab2_AltmQty,
            this.tab2_allSotckQty,
            this.tab2_useQty,
            this.tab2_AvailableQty});
            this.tab2_dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.tab2_dataGridView1.Location = new System.Drawing.Point(6, 74);
            this.tab2_dataGridView1.Name = "tab2_dataGridView1";
            this.tab2_dataGridView1.RowTemplate.Height = 23;
            this.tab2_dataGridView1.Size = new System.Drawing.Size(1256, 593);
            this.tab2_dataGridView1.TabIndex = 62;
            this.tab2_dataGridView1.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.tab3_dataGridView1_ColumnHeaderMouseClick);
            this.tab2_dataGridView1.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.tab2_dataGridView1_CellMouseDoubleClick);
            // 
            // tab2_cinvcode
            // 
            this.tab2_cinvcode.DataPropertyName = "cinvcode";
            this.tab2_cinvcode.HeaderText = "物料编码";
            this.tab2_cinvcode.Name = "tab2_cinvcode";
            this.tab2_cinvcode.ReadOnly = true;
            this.tab2_cinvcode.Width = 120;
            // 
            // tab2_cInvName
            // 
            this.tab2_cInvName.DataPropertyName = "cInvName";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle1.Format = "N4";
            dataGridViewCellStyle1.NullValue = null;
            this.tab2_cInvName.DefaultCellStyle = dataGridViewCellStyle1;
            this.tab2_cInvName.HeaderText = "物料名称";
            this.tab2_cInvName.Name = "tab2_cInvName";
            this.tab2_cInvName.ReadOnly = true;
            // 
            // tab2_cInvStd
            // 
            this.tab2_cInvStd.DataPropertyName = "cInvStd";
            this.tab2_cInvStd.HeaderText = "物料规格";
            this.tab2_cInvStd.Name = "tab2_cInvStd";
            this.tab2_cInvStd.ReadOnly = true;
            this.tab2_cInvStd.Width = 120;
            // 
            // tab2_cInvDefine7
            // 
            this.tab2_cInvDefine7.DataPropertyName = "cInvDefine7";
            this.tab2_cInvDefine7.HeaderText = "图号/版次";
            this.tab2_cInvDefine7.Name = "tab2_cInvDefine7";
            this.tab2_cInvDefine7.ReadOnly = true;
            // 
            // tab2_moQty
            // 
            this.tab2_moQty.DataPropertyName = "moQty";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle2.Format = "N0";
            dataGridViewCellStyle2.NullValue = null;
            this.tab2_moQty.DefaultCellStyle = dataGridViewCellStyle2;
            this.tab2_moQty.HeaderText = "在制数";
            this.tab2_moQty.Name = "tab2_moQty";
            this.tab2_moQty.ReadOnly = true;
            // 
            // tab2_Now_PurQty
            // 
            this.tab2_Now_PurQty.DataPropertyName = "Now_PurQty";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle3.Format = "N0";
            dataGridViewCellStyle3.NullValue = null;
            this.tab2_Now_PurQty.DefaultCellStyle = dataGridViewCellStyle3;
            this.tab2_Now_PurQty.HeaderText = "采购在途(A)";
            this.tab2_Now_PurQty.Name = "tab2_Now_PurQty";
            this.tab2_Now_PurQty.ReadOnly = true;
            // 
            // tab2_toArrQty
            // 
            this.tab2_toArrQty.DataPropertyName = "toArrQty";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle4.Format = "N0";
            dataGridViewCellStyle4.NullValue = null;
            this.tab2_toArrQty.DefaultCellStyle = dataGridViewCellStyle4;
            this.tab2_toArrQty.HeaderText = "即将到货(A)";
            this.tab2_toArrQty.Name = "tab2_toArrQty";
            this.tab2_toArrQty.ReadOnly = true;
            // 
            // tab2_Now_PurArrQty
            // 
            this.tab2_Now_PurArrQty.DataPropertyName = "Now_PurArrQty";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle5.Format = "N0";
            dataGridViewCellStyle5.NullValue = null;
            this.tab2_Now_PurArrQty.DefaultCellStyle = dataGridViewCellStyle5;
            this.tab2_Now_PurArrQty.HeaderText = "到货在检量(B)";
            this.tab2_Now_PurArrQty.Name = "tab2_Now_PurArrQty";
            this.tab2_Now_PurArrQty.ReadOnly = true;
            // 
            // tab2_CurSotckQty
            // 
            this.tab2_CurSotckQty.DataPropertyName = "CurSotckQty";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle6.Format = "N0";
            dataGridViewCellStyle6.NullValue = null;
            this.tab2_CurSotckQty.DefaultCellStyle = dataGridViewCellStyle6;
            this.tab2_CurSotckQty.HeaderText = "现存量(C)";
            this.tab2_CurSotckQty.Name = "tab2_CurSotckQty";
            this.tab2_CurSotckQty.ReadOnly = true;
            // 
            // tab2_AltmQty
            // 
            this.tab2_AltmQty.DataPropertyName = "AltmQty";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle7.Format = "N0";
            dataGridViewCellStyle7.NullValue = null;
            this.tab2_AltmQty.DefaultCellStyle = dataGridViewCellStyle7;
            this.tab2_AltmQty.HeaderText = "替代料（E）";
            this.tab2_AltmQty.Name = "tab2_AltmQty";
            this.tab2_AltmQty.ReadOnly = true;
            // 
            // tab2_allSotckQty
            // 
            this.tab2_allSotckQty.DataPropertyName = "allSotckQty";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle8.Format = "N0";
            dataGridViewCellStyle8.NullValue = null;
            this.tab2_allSotckQty.DefaultCellStyle = dataGridViewCellStyle8;
            this.tab2_allSotckQty.HeaderText = "在库量(B+C)";
            this.tab2_allSotckQty.Name = "tab2_allSotckQty";
            this.tab2_allSotckQty.ReadOnly = true;
            // 
            // tab2_useQty
            // 
            this.tab2_useQty.DataPropertyName = "useQty";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle9.Format = "N0";
            dataGridViewCellStyle9.NullValue = null;
            this.tab2_useQty.DefaultCellStyle = dataGridViewCellStyle9;
            this.tab2_useQty.HeaderText = "已分配量(D)";
            this.tab2_useQty.Name = "tab2_useQty";
            this.tab2_useQty.ReadOnly = true;
            // 
            // tab2_AvailableQty
            // 
            this.tab2_AvailableQty.DataPropertyName = "AvailableQty";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle10.Format = "N0";
            dataGridViewCellStyle10.NullValue = null;
            this.tab2_AvailableQty.DefaultCellStyle = dataGridViewCellStyle10;
            this.tab2_AvailableQty.HeaderText = "可用量(A+B+C-D)";
            this.tab2_AvailableQty.Name = "tab2_AvailableQty";
            this.tab2_AvailableQty.ReadOnly = true;
            // 
            // tab1_chkPurQtyState
            // 
            this.tab1_chkPurQtyState.AutoSize = true;
            this.tab1_chkPurQtyState.Location = new System.Drawing.Point(446, 47);
            this.tab1_chkPurQtyState.Name = "tab1_chkPurQtyState";
            this.tab1_chkPurQtyState.Size = new System.Drawing.Size(96, 16);
            this.tab1_chkPurQtyState.TabIndex = 70;
            this.tab1_chkPurQtyState.Text = "仅计即将到货";
            this.tab1_chkPurQtyState.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(248, 47);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(22, 15);
            this.label10.TabIndex = 69;
            this.label10.Text = "至";
            // 
            // tab2_DateH
            // 
            this.tab2_DateH.CustomFormat = "yyyy-MM-dd";
            this.tab2_DateH.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tab2_DateH.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.tab2_DateH.Location = new System.Drawing.Point(301, 42);
            this.tab2_DateH.Name = "tab2_DateH";
            this.tab2_DateH.Size = new System.Drawing.Size(127, 25);
            this.tab2_DateH.TabIndex = 68;
            this.tab2_DateH.Value = new System.DateTime(2013, 10, 11, 0, 0, 0, 0);
            // 
            // tab2_DateL
            // 
            this.tab2_DateL.CustomFormat = "yyyy-MM-dd";
            this.tab2_DateL.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tab2_DateL.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.tab2_DateL.Location = new System.Drawing.Point(115, 42);
            this.tab2_DateL.Name = "tab2_DateL";
            this.tab2_DateL.Size = new System.Drawing.Size(127, 25);
            this.tab2_DateL.TabIndex = 67;
            this.tab2_DateL.Value = new System.DateTime(2013, 10, 11, 0, 0, 0, 0);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(14, 49);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 15);
            this.label3.TabIndex = 66;
            this.label3.Text = "需求时间：";
            // 
            // tab2_cInvCodeL
            // 
            this.tab2_cInvCodeL.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tab2_cInvCodeL.Location = new System.Drawing.Point(94, 11);
            this.tab2_cInvCodeL.Name = "tab2_cInvCodeL";
            this.tab2_cInvCodeL.Size = new System.Drawing.Size(197, 25);
            this.tab2_cInvCodeL.TabIndex = 62;
            this.tab2_cInvCodeL.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.tab2_cInvCodeL_MouseDoubleClick);
            this.tab2_cInvCodeL.Leave += new System.EventHandler(this.tab2_cInvCodeL_Leave);
            // 
            // tab2_cInvCodeH
            // 
            this.tab2_cInvCodeH.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tab2_cInvCodeH.Location = new System.Drawing.Point(328, 11);
            this.tab2_cInvCodeH.Name = "tab2_cInvCodeH";
            this.tab2_cInvCodeH.Size = new System.Drawing.Size(197, 25);
            this.tab2_cInvCodeH.TabIndex = 63;
            this.tab2_cInvCodeH.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.tab2_cInvCodeH_MouseDoubleClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(298, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(22, 15);
            this.label1.TabIndex = 64;
            this.label1.Text = "至";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(14, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 15);
            this.label2.TabIndex = 61;
            this.label2.Text = "物料编码：";
            // 
            // tab2AllStockDetail
            // 
            this.tab2AllStockDetail.Controls.Add(this.tab1_chkShow67);
            this.tab2AllStockDetail.Controls.Add(this.tab1_chkShow5);
            this.tab2AllStockDetail.Controls.Add(this.tab1_chkShow4);
            this.tab2AllStockDetail.Controls.Add(this.tab1_chkShow3);
            this.tab2AllStockDetail.Controls.Add(this.tab1_chkShow12);
            this.tab2AllStockDetail.Controls.Add(this.chkShowAll);
            this.tab2AllStockDetail.Controls.Add(this.chkShowProd);
            this.tab2AllStockDetail.Controls.Add(this.tab1_cinvCodeAny);
            this.tab2AllStockDetail.Controls.Add(this.label7);
            this.tab2AllStockDetail.Controls.Add(this.tab1_cInvCodeL);
            this.tab2AllStockDetail.Controls.Add(this.tab1_cInvCodeH);
            this.tab2AllStockDetail.Controls.Add(this.label4);
            this.tab2AllStockDetail.Controls.Add(this.label5);
            this.tab2AllStockDetail.Controls.Add(this.tab1_dataGridView1);
            this.tab2AllStockDetail.Location = new System.Drawing.Point(4, 4);
            this.tab2AllStockDetail.Name = "tab2AllStockDetail";
            this.tab2AllStockDetail.Padding = new System.Windows.Forms.Padding(3);
            this.tab2AllStockDetail.Size = new System.Drawing.Size(1268, 673);
            this.tab2AllStockDetail.TabIndex = 1;
            this.tab2AllStockDetail.Text = "库存明细";
            this.tab2AllStockDetail.UseVisualStyleBackColor = true;
            // 
            // tab1_chkShow67
            // 
            this.tab1_chkShow67.AutoSize = true;
            this.tab1_chkShow67.Location = new System.Drawing.Point(524, 44);
            this.tab1_chkShow67.Name = "tab1_chkShow67";
            this.tab1_chkShow67.Size = new System.Drawing.Size(72, 16);
            this.tab1_chkShow67.TabIndex = 84;
            this.tab1_chkShow67.Text = "已分配量";
            this.tab1_chkShow67.UseVisualStyleBackColor = true;
            // 
            // tab1_chkShow5
            // 
            this.tab1_chkShow5.AutoSize = true;
            this.tab1_chkShow5.Location = new System.Drawing.Point(470, 44);
            this.tab1_chkShow5.Name = "tab1_chkShow5";
            this.tab1_chkShow5.Size = new System.Drawing.Size(48, 16);
            this.tab1_chkShow5.TabIndex = 83;
            this.tab1_chkShow5.Text = "在制";
            this.tab1_chkShow5.UseVisualStyleBackColor = true;
            // 
            // tab1_chkShow4
            // 
            this.tab1_chkShow4.AutoSize = true;
            this.tab1_chkShow4.Location = new System.Drawing.Point(404, 44);
            this.tab1_chkShow4.Name = "tab1_chkShow4";
            this.tab1_chkShow4.Size = new System.Drawing.Size(60, 16);
            this.tab1_chkShow4.TabIndex = 82;
            this.tab1_chkShow4.Text = "现存量";
            this.tab1_chkShow4.UseVisualStyleBackColor = true;
            // 
            // tab1_chkShow3
            // 
            this.tab1_chkShow3.AutoSize = true;
            this.tab1_chkShow3.Location = new System.Drawing.Point(326, 44);
            this.tab1_chkShow3.Name = "tab1_chkShow3";
            this.tab1_chkShow3.Size = new System.Drawing.Size(72, 16);
            this.tab1_chkShow3.TabIndex = 81;
            this.tab1_chkShow3.Text = "到货在检";
            this.tab1_chkShow3.UseVisualStyleBackColor = true;
            // 
            // tab1_chkShow12
            // 
            this.tab1_chkShow12.AutoSize = true;
            this.tab1_chkShow12.Location = new System.Drawing.Point(248, 44);
            this.tab1_chkShow12.Name = "tab1_chkShow12";
            this.tab1_chkShow12.Size = new System.Drawing.Size(72, 16);
            this.tab1_chkShow12.TabIndex = 80;
            this.tab1_chkShow12.Text = "采购在途";
            this.tab1_chkShow12.UseVisualStyleBackColor = true;
            // 
            // chkShowAll
            // 
            this.chkShowAll.AutoSize = true;
            this.chkShowAll.Location = new System.Drawing.Point(119, 44);
            this.chkShowAll.Name = "chkShowAll";
            this.chkShowAll.Size = new System.Drawing.Size(72, 16);
            this.chkShowAll.TabIndex = 79;
            this.chkShowAll.Text = "同屏显示";
            this.chkShowAll.UseVisualStyleBackColor = true;
            // 
            // chkShowProd
            // 
            this.chkShowProd.AutoSize = true;
            this.chkShowProd.Location = new System.Drawing.Point(17, 44);
            this.chkShowProd.Name = "chkShowProd";
            this.chkShowProd.Size = new System.Drawing.Size(96, 16);
            this.chkShowProd.TabIndex = 78;
            this.chkShowProd.Text = "显示产品信息";
            this.chkShowProd.UseVisualStyleBackColor = true;
            this.chkShowProd.CheckedChanged += new System.EventHandler(this.chkShowProd_CheckedChanged);
            // 
            // tab1_cinvCodeAny
            // 
            this.tab1_cinvCodeAny.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tab1_cinvCodeAny.Location = new System.Drawing.Point(591, 6);
            this.tab1_cinvCodeAny.Name = "tab1_cinvCodeAny";
            this.tab1_cinvCodeAny.Size = new System.Drawing.Size(266, 25);
            this.tab1_cinvCodeAny.TabIndex = 77;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(422, 10);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(158, 15);
            this.label7.TabIndex = 76;
            this.label7.Text = "多个物料(以分号隔开)";
            // 
            // tab1_cInvCodeL
            // 
            this.tab1_cInvCodeL.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tab1_cInvCodeL.Location = new System.Drawing.Point(89, 6);
            this.tab1_cInvCodeL.Name = "tab1_cInvCodeL";
            this.tab1_cInvCodeL.Size = new System.Drawing.Size(135, 25);
            this.tab1_cInvCodeL.TabIndex = 66;
            this.tab1_cInvCodeL.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.tab1_cInvCodeL_MouseDoubleClick);
            this.tab1_cInvCodeL.Leave += new System.EventHandler(this.tab1_cInvCodeL_Leave);
            // 
            // tab1_cInvCodeH
            // 
            this.tab1_cInvCodeH.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tab1_cInvCodeH.Location = new System.Drawing.Point(273, 6);
            this.tab1_cInvCodeH.Name = "tab1_cInvCodeH";
            this.tab1_cInvCodeH.Size = new System.Drawing.Size(135, 25);
            this.tab1_cInvCodeH.TabIndex = 67;
            this.tab1_cInvCodeH.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.tab1_cInvCodeH_MouseDoubleClick);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(245, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(22, 15);
            this.label4.TabIndex = 68;
            this.label4.Text = "至";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(9, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 15);
            this.label5.TabIndex = 65;
            this.label5.Text = "物料编码：";
            // 
            // tab1_dataGridView1
            // 
            this.tab1_dataGridView1.AllowUserToAddRows = false;
            this.tab1_dataGridView1.AllowUserToDeleteRows = false;
            this.tab1_dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tab1_dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.tab1_dataGridView1.Location = new System.Drawing.Point(6, 73);
            this.tab1_dataGridView1.Name = "tab1_dataGridView1";
            this.tab1_dataGridView1.RowTemplate.Height = 23;
            this.tab1_dataGridView1.Size = new System.Drawing.Size(1256, 594);
            this.tab1_dataGridView1.TabIndex = 61;
            this.tab1_dataGridView1.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.tab1_dataGridView1_CellMouseUp);
            this.tab1_dataGridView1.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.tab1_dataGridView1_ColumnHeaderMouseClick);
            this.tab1_dataGridView1.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.tab1_dataGridView1_CellMouseDown_1);
            this.tab1_dataGridView1.CellMouseMove += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.tab1_dataGridView1_CellMouseMove);
            this.tab1_dataGridView1.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.tab1_dataGridView1_CellMouseDoubleClick);
            // 
            // tab3PurSource
            // 
            this.tab3PurSource.Controls.Add(this.tab3_dDateHCHK);
            this.tab3PurSource.Controls.Add(this.tab3_dDateLCHK);
            this.tab3PurSource.Controls.Add(this.tab3_cMaker);
            this.tab3PurSource.Controls.Add(this.label14);
            this.tab3PurSource.Controls.Add(this.tab3_dDateH);
            this.tab3PurSource.Controls.Add(this.tab3_dDateL);
            this.tab3PurSource.Controls.Add(this.label13);
            this.tab3PurSource.Controls.Add(this.label12);
            this.tab3PurSource.Controls.Add(this.tab3_cCode);
            this.tab3PurSource.Controls.Add(this.label11);
            this.tab3PurSource.Controls.Add(this.label9);
            this.tab3PurSource.Controls.Add(this.tab3_cInvCode);
            this.tab3PurSource.Controls.Add(this.label8);
            this.tab3PurSource.Controls.Add(this.tab3_dataGridView1);
            this.tab3PurSource.Location = new System.Drawing.Point(4, 4);
            this.tab3PurSource.Name = "tab3PurSource";
            this.tab3PurSource.Size = new System.Drawing.Size(1268, 673);
            this.tab3PurSource.TabIndex = 2;
            this.tab3PurSource.Text = "请购来源";
            this.tab3PurSource.UseVisualStyleBackColor = true;
            // 
            // tab3_dDateHCHK
            // 
            this.tab3_dDateHCHK.AutoSize = true;
            this.tab3_dDateHCHK.Location = new System.Drawing.Point(486, 46);
            this.tab3_dDateHCHK.Name = "tab3_dDateHCHK";
            this.tab3_dDateHCHK.Size = new System.Drawing.Size(15, 14);
            this.tab3_dDateHCHK.TabIndex = 90;
            this.tab3_dDateHCHK.UseVisualStyleBackColor = true;
            this.tab3_dDateHCHK.CheckedChanged += new System.EventHandler(this.tab3_dDateHCHK_CheckedChanged);
            // 
            // tab3_dDateLCHK
            // 
            this.tab3_dDateLCHK.AutoSize = true;
            this.tab3_dDateLCHK.Location = new System.Drawing.Point(310, 46);
            this.tab3_dDateLCHK.Name = "tab3_dDateLCHK";
            this.tab3_dDateLCHK.Size = new System.Drawing.Size(15, 14);
            this.tab3_dDateLCHK.TabIndex = 89;
            this.tab3_dDateLCHK.UseVisualStyleBackColor = true;
            this.tab3_dDateLCHK.CheckedChanged += new System.EventHandler(this.tab3_dDateLCHK_CheckedChanged);
            // 
            // tab3_cMaker
            // 
            this.tab3_cMaker.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tab3_cMaker.Location = new System.Drawing.Point(761, 41);
            this.tab3_cMaker.Name = "tab3_cMaker";
            this.tab3_cMaker.Size = new System.Drawing.Size(102, 25);
            this.tab3_cMaker.TabIndex = 88;
            this.tab3_cMaker.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.tab3_cMaker_MouseDoubleClick);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(703, 46);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(52, 15);
            this.label14.TabIndex = 87;
            this.label14.Text = "制单人";
            // 
            // tab3_dDateH
            // 
            this.tab3_dDateH.CustomFormat = "yyyy-MM-dd";
            this.tab3_dDateH.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tab3_dDateH.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.tab3_dDateH.Location = new System.Drawing.Point(510, 41);
            this.tab3_dDateH.Name = "tab3_dDateH";
            this.tab3_dDateH.Size = new System.Drawing.Size(138, 25);
            this.tab3_dDateH.TabIndex = 86;
            this.tab3_dDateH.Value = new System.DateTime(2013, 10, 11, 0, 0, 0, 0);
            // 
            // tab3_dDateL
            // 
            this.tab3_dDateL.CustomFormat = "yyyy-MM-dd";
            this.tab3_dDateL.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tab3_dDateL.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.tab3_dDateL.Location = new System.Drawing.Point(331, 41);
            this.tab3_dDateL.Name = "tab3_dDateL";
            this.tab3_dDateL.Size = new System.Drawing.Size(121, 25);
            this.tab3_dDateL.TabIndex = 85;
            this.tab3_dDateL.Value = new System.DateTime(2013, 10, 11, 0, 0, 0, 0);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.Location = new System.Drawing.Point(458, 46);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(22, 15);
            this.label13.TabIndex = 84;
            this.label13.Text = "至";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(235, 46);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 15);
            this.label12.TabIndex = 82;
            this.label12.Text = "请购日期";
            // 
            // tab3_cCode
            // 
            this.tab3_cCode.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tab3_cCode.Location = new System.Drawing.Point(81, 41);
            this.tab3_cCode.Name = "tab3_cCode";
            this.tab3_cCode.Size = new System.Drawing.Size(148, 25);
            this.tab3_cCode.TabIndex = 81;
            this.tab3_cCode.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.tab3_cCode_MouseDoubleClick);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(8, 46);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(67, 15);
            this.label11.TabIndex = 80;
            this.label11.Text = "请购单号";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(607, 14);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(165, 15);
            this.label9.TabIndex = 79;
            this.label9.Text = "（多个物料以分号隔开)";
            // 
            // tab3_cInvCode
            // 
            this.tab3_cInvCode.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tab3_cInvCode.Location = new System.Drawing.Point(81, 9);
            this.tab3_cInvCode.Name = "tab3_cInvCode";
            this.tab3_cInvCode.Size = new System.Drawing.Size(519, 25);
            this.tab3_cInvCode.TabIndex = 78;
            this.tab3_cInvCode.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.tab3_cInvCode_MouseDoubleClick);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(8, 14);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 15);
            this.label8.TabIndex = 77;
            this.label8.Text = "物料编码";
            // 
            // tab3_dataGridView1
            // 
            this.tab3_dataGridView1.AllowUserToAddRows = false;
            this.tab3_dataGridView1.AllowUserToDeleteRows = false;
            this.tab3_dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tab3_dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.tab3_dataGridView1.Location = new System.Drawing.Point(6, 72);
            this.tab3_dataGridView1.Name = "tab3_dataGridView1";
            this.tab3_dataGridView1.RowTemplate.Height = 23;
            this.tab3_dataGridView1.Size = new System.Drawing.Size(1256, 590);
            this.tab3_dataGridView1.TabIndex = 76;
            this.tab3_dataGridView1.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.tab3_dataGridView1_CellMouseUp);
            this.tab3_dataGridView1.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.tab3_dataGridView1_ColumnHeaderMouseClick);
            this.tab3_dataGridView1.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.tab3_dataGridView1_CellMouseDown);
            this.tab3_dataGridView1.CellMouseMove += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.tab3_dataGridView1_CellMouseMove);
            // 
            // tab4MoSource
            // 
            this.tab4MoSource.Controls.Add(this.tab4_CreateUser);
            this.tab4MoSource.Controls.Add(this.label15);
            this.tab4MoSource.Controls.Add(this.tab4_MoCode);
            this.tab4MoSource.Controls.Add(this.label17);
            this.tab4MoSource.Controls.Add(this.label18);
            this.tab4MoSource.Controls.Add(this.tab4_cInvCode);
            this.tab4MoSource.Controls.Add(this.label19);
            this.tab4MoSource.Controls.Add(this.tab4_dataGridView1);
            this.tab4MoSource.Location = new System.Drawing.Point(4, 4);
            this.tab4MoSource.Name = "tab4MoSource";
            this.tab4MoSource.Size = new System.Drawing.Size(1268, 673);
            this.tab4MoSource.TabIndex = 3;
            this.tab4MoSource.Text = "制单来源";
            this.tab4MoSource.UseVisualStyleBackColor = true;
            // 
            // tab4_CreateUser
            // 
            this.tab4_CreateUser.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tab4_CreateUser.Location = new System.Drawing.Point(306, 41);
            this.tab4_CreateUser.Name = "tab4_CreateUser";
            this.tab4_CreateUser.Size = new System.Drawing.Size(102, 25);
            this.tab4_CreateUser.TabIndex = 99;
            this.tab4_CreateUser.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.tab4_CreateUser_MouseDoubleClick);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.Location = new System.Drawing.Point(248, 46);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(52, 15);
            this.label15.TabIndex = 98;
            this.label15.Text = "制单人";
            // 
            // tab4_MoCode
            // 
            this.tab4_MoCode.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tab4_MoCode.Location = new System.Drawing.Point(81, 42);
            this.tab4_MoCode.Name = "tab4_MoCode";
            this.tab4_MoCode.Size = new System.Drawing.Size(148, 25);
            this.tab4_MoCode.TabIndex = 94;
            this.tab4_MoCode.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.tab4_MoCode_MouseDoubleClick);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label17.Location = new System.Drawing.Point(8, 47);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(67, 15);
            this.label17.TabIndex = 93;
            this.label17.Text = "制造单号";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label18.ForeColor = System.Drawing.Color.Red;
            this.label18.Location = new System.Drawing.Point(607, 15);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(165, 15);
            this.label18.TabIndex = 92;
            this.label18.Text = "（多个物料以分号隔开)";
            // 
            // tab4_cInvCode
            // 
            this.tab4_cInvCode.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tab4_cInvCode.Location = new System.Drawing.Point(81, 10);
            this.tab4_cInvCode.Name = "tab4_cInvCode";
            this.tab4_cInvCode.Size = new System.Drawing.Size(519, 25);
            this.tab4_cInvCode.TabIndex = 91;
            this.tab4_cInvCode.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.tab4_cInvCode_MouseDoubleClick);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label19.Location = new System.Drawing.Point(8, 15);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(67, 15);
            this.label19.TabIndex = 90;
            this.label19.Text = "物料编码";
            // 
            // tab4_dataGridView1
            // 
            this.tab4_dataGridView1.AllowUserToAddRows = false;
            this.tab4_dataGridView1.AllowUserToDeleteRows = false;
            this.tab4_dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tab4_dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.tab4_dataGridView1.Location = new System.Drawing.Point(6, 73);
            this.tab4_dataGridView1.Name = "tab4_dataGridView1";
            this.tab4_dataGridView1.RowTemplate.Height = 23;
            this.tab4_dataGridView1.Size = new System.Drawing.Size(1256, 590);
            this.tab4_dataGridView1.TabIndex = 89;
            this.tab4_dataGridView1.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.tab4_dataGridView1_CellMouseUp);
            this.tab4_dataGridView1.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.tab4_dataGridView1_ColumnHeaderMouseClick);
            this.tab4_dataGridView1.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.tab4_dataGridView1_CellMouseDown);
            this.tab4_dataGridView1.CellMouseMove += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.tab4_dataGridView1_CellMouseMove);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolQuery,
            this.toolRefresh,
            this.toolEdit,
            this.toolSave,
            this.toolToExcel,
            this.toolClose});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1284, 40);
            this.toolStrip1.TabIndex = 57;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolQuery
            // 
            this.toolQuery.Image = ((System.Drawing.Image)(resources.GetObject("toolQuery.Image")));
            this.toolQuery.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolQuery.Name = "toolQuery";
            this.toolQuery.Size = new System.Drawing.Size(36, 37);
            this.toolQuery.Text = "查询";
            this.toolQuery.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolQuery.Click += new System.EventHandler(this.toolQuery_Click);
            // 
            // toolRefresh
            // 
            this.toolRefresh.Image = ((System.Drawing.Image)(resources.GetObject("toolRefresh.Image")));
            this.toolRefresh.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolRefresh.Name = "toolRefresh";
            this.toolRefresh.Size = new System.Drawing.Size(36, 37);
            this.toolRefresh.Text = "刷新";
            this.toolRefresh.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolRefresh.Click += new System.EventHandler(this.toolRefresh_Click);
            // 
            // toolEdit
            // 
            this.toolEdit.Image = ((System.Drawing.Image)(resources.GetObject("toolEdit.Image")));
            this.toolEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolEdit.Name = "toolEdit";
            this.toolEdit.Size = new System.Drawing.Size(36, 37);
            this.toolEdit.Text = "修改";
            this.toolEdit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolEdit.Click += new System.EventHandler(this.toolEdit_Click);
            // 
            // toolSave
            // 
            this.toolSave.Image = ((System.Drawing.Image)(resources.GetObject("toolSave.Image")));
            this.toolSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolSave.Name = "toolSave";
            this.toolSave.Size = new System.Drawing.Size(36, 37);
            this.toolSave.Text = "保存";
            this.toolSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolSave.Click += new System.EventHandler(this.toolSave_Click);
            // 
            // toolToExcel
            // 
            this.toolToExcel.Image = ((System.Drawing.Image)(resources.GetObject("toolToExcel.Image")));
            this.toolToExcel.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolToExcel.Name = "toolToExcel";
            this.toolToExcel.Size = new System.Drawing.Size(41, 37);
            this.toolToExcel.Text = "Excel";
            this.toolToExcel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolToExcel.Click += new System.EventHandler(this.toolToExcel_Click);
            // 
            // toolClose
            // 
            this.toolClose.Image = ((System.Drawing.Image)(resources.GetObject("toolClose.Image")));
            this.toolClose.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolClose.Name = "toolClose";
            this.toolClose.Size = new System.Drawing.Size(36, 37);
            this.toolClose.Text = "退出";
            this.toolClose.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolClose.Click += new System.EventHandler(this.toolClose_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SLbServer,
            this.SLbAccID,
            this.SLbAccName,
            this.SLbYear,
            this.SLbUser,
            this.SLBLoginDate,
            this.SLBTotal,
            this.SLbState});
            this.statusStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.statusStrip1.Location = new System.Drawing.Point(0, 745);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1284, 26);
            this.statusStrip1.TabIndex = 58;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // SLbServer
            // 
            this.SLbServer.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)));
            this.SLbServer.Name = "SLbServer";
            this.SLbServer.Size = new System.Drawing.Size(48, 21);
            this.SLbServer.Text = "服务器";
            this.SLbServer.ToolTipText = "服务器";
            // 
            // SLbAccID
            // 
            this.SLbAccID.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)));
            this.SLbAccID.Name = "SLbAccID";
            this.SLbAccID.Size = new System.Drawing.Size(48, 21);
            this.SLbAccID.Spring = true;
            this.SLbAccID.Text = "帐套号";
            this.SLbAccID.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            // 
            // SLbAccName
            // 
            this.SLbAccName.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)));
            this.SLbAccName.Name = "SLbAccName";
            this.SLbAccName.Size = new System.Drawing.Size(60, 21);
            this.SLbAccName.Text = "帐套名称";
            // 
            // SLbYear
            // 
            this.SLbYear.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)));
            this.SLbYear.Name = "SLbYear";
            this.SLbYear.Size = new System.Drawing.Size(36, 21);
            this.SLbYear.Text = "年度";
            // 
            // SLbUser
            // 
            this.SLbUser.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)));
            this.SLbUser.Name = "SLbUser";
            this.SLbUser.Size = new System.Drawing.Size(48, 21);
            this.SLbUser.Text = "用户名";
            // 
            // SLBLoginDate
            // 
            this.SLBLoginDate.Name = "SLBLoginDate";
            this.SLBLoginDate.Size = new System.Drawing.Size(131, 21);
            this.SLBLoginDate.Text = "toolStripStatusLabel1";
            // 
            // SLBTotal
            // 
            this.SLBTotal.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)));
            this.SLBTotal.ForeColor = System.Drawing.Color.Red;
            this.SLBTotal.Name = "SLBTotal";
            this.SLBTotal.Size = new System.Drawing.Size(4, 21);
            // 
            // SLbState
            // 
            this.SLbState.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)));
            this.SLbState.Name = "SLbState";
            this.SLbState.Size = new System.Drawing.Size(4, 21);
            // 
            // tab6_StandardCut
            // 
            this.tab6_StandardCut.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tab6_toStandard,
            this.tab6_toNotStandard});
            this.tab6_StandardCut.Name = "tab6_StandardCut";
            this.tab6_StandardCut.Size = new System.Drawing.Size(177, 22);
            this.tab6_StandardCut.Text = "【标准/非标】切换";
            // 
            // tab6_toStandard
            // 
            this.tab6_toStandard.Name = "tab6_toStandard";
            this.tab6_toStandard.Size = new System.Drawing.Size(160, 22);
            this.tab6_toStandard.Text = "切换为【标准】";
            this.tab6_toStandard.Click += new System.EventHandler(this.tab6_toStandard_Click);
            // 
            // tab6_toNotStandard
            // 
            this.tab6_toNotStandard.Name = "tab6_toNotStandard";
            this.tab6_toNotStandard.Size = new System.Drawing.Size(160, 22);
            this.tab6_toNotStandard.Text = "切换为【非标】";
            this.tab6_toNotStandard.Click += new System.EventHandler(this.tab6_toNotStandard_Click);
            // 
            // frmRSERP_APS21Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1284, 771);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmRSERP_APS21Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "排产管理";
            this.Load += new System.EventHandler(this.frmRSERP_APS21_Load);
            this.Shown += new System.EventHandler(this.frmRSERP_APS21_Shown);
            this.Resize += new System.EventHandler(this.frmRSERP_APS21_Resize);
            this.tabControl1.ResumeLayout(false);
            this.tab6APS.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tab6_dataGridView1)).EndInit();
            this.contextMenu_Tab6.ResumeLayout(false);
            this.tab8MOMSupply.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tab8_dataGridView1)).EndInit();
            this.tab1AllStock.ResumeLayout(false);
            this.tab1AllStock.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tab2_dataGridView1)).EndInit();
            this.tab2AllStockDetail.ResumeLayout(false);
            this.tab2AllStockDetail.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tab1_dataGridView1)).EndInit();
            this.tab3PurSource.ResumeLayout(false);
            this.tab3PurSource.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tab3_dataGridView1)).EndInit();
            this.tab4MoSource.ResumeLayout(false);
            this.tab4MoSource.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tab4_dataGridView1)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tab1AllStock;
        private System.Windows.Forms.TabPage tab2AllStockDetail;
        private System.Windows.Forms.DataGridView tab1_dataGridView1;
        private System.Windows.Forms.TextBox tab2_cInvCodeL;
        private System.Windows.Forms.TextBox tab2_cInvCodeH;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker tab2_DateH;
        private System.Windows.Forms.DateTimePicker tab2_DateL;
        private System.Windows.Forms.CheckBox tab1_chkPurQtyState;
        private System.Windows.Forms.DataGridView tab2_dataGridView1;
        private System.Windows.Forms.CheckBox tab2_chkMissingOnly;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolQuery;
        private System.Windows.Forms.ToolStripButton toolToExcel;
        private System.Windows.Forms.ToolStripButton toolClose;
        private System.Windows.Forms.TextBox tab1_cInvCodeL;
        private System.Windows.Forms.TextBox tab1_cInvCodeH;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tab2_cinvCodeAny;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tab1_cinvCodeAny;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TabPage tab3PurSource;
        private System.Windows.Forms.TextBox tab3_cInvCode;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridView tab3_dataGridView1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tab3_cCode;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DateTimePicker tab3_dDateH;
        private System.Windows.Forms.DateTimePicker tab3_dDateL;
        private System.Windows.Forms.TextBox tab3_cMaker;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel SLbServer;
        private System.Windows.Forms.ToolStripStatusLabel SLbAccID;
        private System.Windows.Forms.ToolStripStatusLabel SLbAccName;
        private System.Windows.Forms.ToolStripStatusLabel SLbYear;
        private System.Windows.Forms.ToolStripStatusLabel SLbUser;
        private System.Windows.Forms.ToolStripStatusLabel SLBTotal;
        private System.Windows.Forms.ToolStripStatusLabel SLbState;
        private System.Windows.Forms.CheckBox chkShowProd;
        private System.Windows.Forms.DataGridViewTextBoxColumn tab2_cinvcode;
        private System.Windows.Forms.DataGridViewTextBoxColumn tab2_cInvName;
        private System.Windows.Forms.DataGridViewTextBoxColumn tab2_cInvStd;
        private System.Windows.Forms.DataGridViewTextBoxColumn tab2_cInvDefine7;
        private System.Windows.Forms.DataGridViewTextBoxColumn tab2_moQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn tab2_Now_PurQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn tab2_toArrQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn tab2_Now_PurArrQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn tab2_CurSotckQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn tab2_AltmQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn tab2_allSotckQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn tab2_useQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn tab2_AvailableQty;
        private System.Windows.Forms.TabPage tab4MoSource;
        private System.Windows.Forms.TextBox tab4_CreateUser;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tab4_MoCode;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox tab4_cInvCode;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.DataGridView tab4_dataGridView1;
        private System.Windows.Forms.CheckBox chkShowAll;
        private System.Windows.Forms.CheckBox tab2_DateLCHK;
        private System.Windows.Forms.CheckBox tab2_DateHCHK;
        private System.Windows.Forms.CheckBox tab3_dDateHCHK;
        private System.Windows.Forms.CheckBox tab3_dDateLCHK;
        private System.Windows.Forms.CheckBox tab1_chkShow3;
        private System.Windows.Forms.CheckBox tab1_chkShow12;
        private System.Windows.Forms.CheckBox tab1_chkShow4;
        private System.Windows.Forms.CheckBox tab1_chkShow67;
        private System.Windows.Forms.CheckBox tab1_chkShow5;
        private System.Windows.Forms.TabPage tab5OrderTotal;
        private System.Windows.Forms.TabPage tab6APS;
        private System.Windows.Forms.TabPage tab7DeliverySchedule;
        private System.Windows.Forms.TabPage tab8MOMSupply;
        private System.Windows.Forms.DataGridView tab6_dataGridView1;
        private System.Windows.Forms.ToolStripButton toolEdit;
        private System.Windows.Forms.ToolStripButton toolSave;
        private System.Windows.Forms.ToolStripButton toolRefresh;
        private System.Windows.Forms.ContextMenuStrip contextMenu_Tab6;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem cmtab6Colors;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem cmtab6SelectAll;
        private System.Windows.Forms.ToolStripMenuItem cmtab6MissingMaterials;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem cmtab6Copy;
        private System.Windows.Forms.ToolStripMenuItem cmtab6Paste;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem cmtab6_other;
        private System.Windows.Forms.ToolStripMenuItem cmtab6_oth_ResetColumnsWidth;
        private System.Windows.Forms.ToolStripMenuItem 字体大小ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cmtab6_Font8;
        private System.Windows.Forms.ToolStripMenuItem cmtab6_Font9;
        private System.Windows.Forms.ToolStripMenuItem cmtab6_Font10;
        private System.Windows.Forms.ToolStripMenuItem cmtab6_Font11;
        private System.Windows.Forms.ToolStripMenuItem cmtab6_Font12;
        private System.Windows.Forms.ToolStripMenuItem cmtab6_Font13;
        private System.Windows.Forms.ToolStripMenuItem cmtab6_Font14;
        private System.Windows.Forms.ToolStripMenuItem cmtab6_Font15;
        private System.Windows.Forms.ToolStripMenuItem cmtab6_Font16;
        private System.Windows.Forms.ToolStripMenuItem cmtab6Plan;
        private System.Windows.Forms.ToolStripMenuItem cmtab6Sure2;
        private System.Windows.Forms.ToolStripMenuItem cmtab6NotSure;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem cmtab6Close;
        private System.Windows.Forms.ToolStripMenuItem cmtab6NotColse;
        private System.Windows.Forms.ToolStripMenuItem cmtab6ChangeDate;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem cmtab6RowCut;
        private System.Windows.Forms.ToolStripMenuItem cmtab6RowPaste;
        private System.Windows.Forms.ToolStripMenuItem cmtab6Priority;
        private System.Windows.Forms.ToolStripMenuItem cmtab6OrderSplit;
        private System.Windows.Forms.ToolStripMenuItem cmtab6OrderMerge;
        private System.Windows.Forms.ToolStripMenuItem cmtab6ColumnFrozen;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem cmtab6ColumnNotFrozen;
        private System.Windows.Forms.ToolStripMenuItem cmtab6FindSimilarity;
        private System.Windows.Forms.ToolStripMenuItem cmtab6ReLoadBOM;
        private System.Windows.Forms.ToolStripMenuItem cmtab6Findword;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem8;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem cmtab6Moallocate;
        private System.Windows.Forms.DataGridView tab8_dataGridView1;
        private System.Windows.Forms.ToolStripStatusLabel SLBLoginDate;
        private System.Windows.Forms.ToolStripMenuItem tab6_StandardCut;
        private System.Windows.Forms.ToolStripMenuItem tab6_toStandard;
        private System.Windows.Forms.ToolStripMenuItem tab6_toNotStandard;

    }
}